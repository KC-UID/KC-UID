#' Extract the section number as "section_num" variable to keep the table and figure number continuous
#'
#' @param name of the input file
#' @param category of the file, gc_content, length or duplication
#' @param type of file, raw or dedup
#' @return data frame
#' @return labels
#' @export


plot_line_dup <- function(data, outpng, title_t, labels, col = "variable", key = "Reads1") {
  data_plot <- data[data[col] == key,]
  p <- ggplot(data_plot, aes(x=Dup, y=value, color = Type)) +
    geom_line(size = 1) +
    theme_bw() +
    #theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank()) +
    theme(plot.title = element_text(hjust = 0.5)) +
    theme(legend.title = element_blank()) +
    scale_color_manual(breaks=c("Clean", "Dedup"), values=c("red", "blue")) +
    ylab(NULL) +
    xlab("Sequence Duplication Level") +
    scale_x_continuous(breaks=seq(1, length(labels)), labels = labels)+
    theme(plot.title = element_text(hjust = 0.5)) +
    ggtitle(title_t)
  ggsave(filename = outpng,
         width = 9, height = 6, units = "in", dpi = 100,
         type="cairo-png", plot = p)
}

