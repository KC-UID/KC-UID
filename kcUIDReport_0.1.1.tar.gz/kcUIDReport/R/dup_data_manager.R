#' Read table and melt
#'
#' @param name of the input file
#' @param category of the file, gc_content, length or duplication
#' @param type of file, raw or dedup
#' @return data frame
#' @return labels
#' @export

dup_data_manager <- function(file, category, type = "Raw"){
  data <- read.table(file, sep = "\t", header = TRUE)
  if (ncol(data) == 3) {
    colnames(data) <- c(category, "Reads1", "Reads2")
    r2_sum <- sum(data$Reads2)
    data$Reads2 <- data$Reads2/r2_sum*100
  } else {
    colnames(data) <- c(category, "Reads1")
  }
  r1_sum <- sum(data$Reads1)
  data$Reads1 <- data$Reads1/r1_sum*100
  labels <- data[, category]
  data[category] <- seq(1, nrow(data))
  data["Type"] <- rep(type, nrow(data))
  data_melt <- melt(data, id.vars = c(category, 'Type'))
  return(list(data_melt, labels))
}