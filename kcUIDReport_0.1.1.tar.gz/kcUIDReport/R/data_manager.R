#' Read table and melt
#'
#' @param name of the input file
#' @param category of the file, gc_content, length or duplication
#' @param type of file, raw or dedup
#' @return data frame
#' @export


data_manager <- function(file, category, type = "Clean"){
  data <- read.table(file, sep = "\t", header = TRUE)
  if (ncol(data) == 3) {
    colnames(data) <- c(category, "Reads1", "Reads2")
    if (nrow(data) == 1) {
      newrow <- c(data[1, 1]-1, 0, 0)
      data <- rbind(data, newrow)
      newrow <- c(data[1, 1]+1, 0, 0)
      data <- rbind(data, newrow)
    }
  } else {
    colnames(data) <- c(category, "Reads1")
    if (nrow(data) == 1) {
      newrow <- c(data[1, 1]-1, 0)
      data <- rbind(data, newrow)
      newrow <- c(data[1, 1]+1, 0)
      data <- rbind(data, newrow)
    }
  }
  data["Type"] <- rep(type, nrow(data))
  data_melt <- melt(data, id.vars = c(category, 'Type'))
  return(data_melt)
}