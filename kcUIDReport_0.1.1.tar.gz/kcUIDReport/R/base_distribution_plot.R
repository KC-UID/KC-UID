#' Read table and melt
#'
#' @param name of the input file
#' @param category of the file, gc_content, length or duplication
#' @param type of file, raw or dedup
#' @return data frame
#' @export

base_distribution_plot <- function(infile, odir, title_t){
  data <- read.table(infile, header = TRUE, sep = "\t")
  data_melt <- melt(data, id.vars = c('Reads', 'Pos'))
  r1pos <- max(data[data$Reads=="r1", "Pos"])
  if ("r2" %in% levels(data_melt$Reads)){
    data_melt[data_melt$Reads=="r2", "Pos"] <-
      data_melt[data_melt$Reads=="r2", "Pos"] + r1pos
  }
  p <- ggplot(data_melt, aes(x = Pos, y = value, colour = variable)) +
    geom_line(size = 0.8) +
    scale_color_manual(values=c("#d7191c", "#fdae61", "#1b9e77", "#2b83ba", "#a6cee3")) +
    scale_x_continuous(breaks = seq(0, nrow(data), 50)) +
    scale_y_continuous(limits = c(0, 1)) +
    ylab("Percent of bases") +
    ggtitle(title_t) +
    theme_bw() +
    theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank()) +
    theme(plot.title = element_text(hjust = 0.5)) +
    theme(legend.title = element_blank())
  
  
  if ("r2" %in% levels(data_melt$Reads)){
    p <- p + geom_vline(xintercept = r1pos, colour = "#756bb1", linetype = "dashed") +
      xlab("Position in PE reads (bp)")
  } else {
    p <- p + xlab("Position in reads (bp)")
  }
  ggsave(filename = file.path(odir, "base_distribution.png"),
         width = 9, height = 6, units = "in", dpi = 100,
         type="cairo-png", plot = p)
}
