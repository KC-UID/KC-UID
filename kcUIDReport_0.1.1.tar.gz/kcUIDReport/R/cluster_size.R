#' Read table and melt
#'
#' @param name of the input file
#' @param category of the file, gc_content, length or duplication
#' @param type of file, raw or dedup
#' @return data frame
#' @export

cluster_size <- function(clu, outdir) {
  data <- read.table(clu, sep = "\t", header = TRUE)
  data$Log <- log(data$Count, 10)
  p <-  ggplot(data, aes(x=Size, y=Log)) +
    geom_bar(stat = "identity") +
    scale_x_continuous(breaks = seq(0, nrow(data), 1)) +
    theme_bw() +
    theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank()) +
    theme(plot.title = element_text(hjust = 0.5)) +
    theme(legend.title = element_blank()) +
    xlab("Cluster Size") +
    ylab("log10(Cluster Frequency)") +
    theme(plot.title = element_text(hjust = 0.5)) +
    ggtitle("The cluster size distribution within UIDs")
  
  
  ggsave(filename = file.path(outdir, "cluster_size.png"),
         width = 9, height = 6, units = "in", dpi = 100, 
         type="cairo-png", plot = p)
  
}