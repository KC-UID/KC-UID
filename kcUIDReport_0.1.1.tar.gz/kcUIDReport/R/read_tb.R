#' Read table and melt
#'
#' @param name of the input file
#' @param category of the file, gc_content, length or duplication
#' @param type of file, raw or dedup
#' @return data frame
#' @export

read_tb <- function(file = "", sep = "\t", header = TRUE) {
  status <- check_file(file)
  if (status) {
    data <- read.table(file, sep = sep, header = header)
    return(list(TRUE, data))
  } else {
    return(list(FALSE, p(class = "NullFile", paste(file, "doesn't exist", sep = " "))))
  }
}