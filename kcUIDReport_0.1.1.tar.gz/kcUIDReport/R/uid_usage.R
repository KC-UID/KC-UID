#' Read table and melt
#'
#' @param name of the input file
#' @param category of the file, gc_content, length or duplication
#' @param type of file, raw or dedup
#' @return data frame
#' @export

uid_usage <- function(uid, outdir) {
  data <- read.table(uid, sep = "\t", header = TRUE)
  rawdata <- rep(data$Usage, data$Count)
  md <- round(median(rawdata), 2)
  me <- round(mean(rawdata), 2)
  
  p <-  ggplot(data, aes(x=Usage, y=Count)) +
    geom_bar(stat = "identity") +
    annotate("text", x=nrow(data)*2/3, y=max(data$Count)*3/4, label=paste("Mean: ", me, sep = "")) +
    annotate("text", x=nrow(data)*2/3, y=(max(data$Count)*1/2), label=paste("Median: ", md, sep = "")) +
    theme_bw() +
    theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank()) +
    theme(plot.title = element_text(hjust = 0.5)) +
    theme(legend.title = element_blank()) +
    #scale_x_continuous(breaks = seq(0, nrow(data), 5)) +
    ylab("Frequency") +
    xlab("UID Usage Frequency") +
    theme(plot.title = element_text(hjust = 0.5)) +
    ggtitle("The UID usage distribution") +
    theme(axis.text.x=element_text(angle=90))
    
  
  ggsave(filename = file.path(outdir, "uid_usage.png"),
         width = 9, height = 6, units = "in", dpi = 100,
         type="cairo-png", plot = p)
}