#' Read table and melt
#'
#' @param name of the input file
#' @param category of the file, gc_content, length or duplication
#' @param type of file, raw or dedup
#' @return data frame
#' @export

main_entry <- function(prodir, sample){
  prodir <- file.path(prodir, sample)
  #UID usage
  uid_usage(file.path(prodir, "uid", "uid_usage.txt"), file.path(prodir, "uid"))
  #Cluster size
  cluster_size(file.path(prodir, "uid", "cluster_size.txt"), file.path(prodir, "uid"))
  
  #Length distribution
  raw <- file.path(prodir, "raw", "length_distribution.txt")
  dedup <- file.path(prodir, "dedup", "length_distribution.txt")
  raw_melt <- data_manager(raw, "Length", "Clean")
  dedup_melt <- data_manager(dedup, "Length", "Dedup")
  data_melt <- rbind(raw_melt, dedup_melt)
  
  outpng <- file.path(prodir, "length_distribution_r1.png")
  plot_line(data_melt, outpng, "Length", xlab_t = "Sequence Length (bp)",
            title_t = "Distribution of sequence lengths over reads1",
            col = "variable", xtick = 5, key = "Reads1")
  
  if (length(levels(data_melt$variable)) == 2) {
    outpng <- file.path(prodir, "length_distribution_r2.png")
    plot_line(data_melt, outpng, "Length", xlab_t = "Sequence Length (bp)",
              title_t = "Distribution of sequence lengths over reads2",
              col = "variable", xtick = 5, key = "Reads2")
  }
  
  #Base distribution
  ##raw
  base_distribution_plot(file.path(prodir, "raw", "per_base_distribution.txt"), 
                         file.path(prodir, "raw"), "The bases distribution along clean reads")
  ##dedup
  base_distribution_plot(file.path(prodir, "dedup", "per_base_distribution.txt"), 
                         file.path(prodir, "dedup"), "The bases distribution along dedup reads")
  
  #GC content
  raw <- file.path(prodir, "raw", "gc_percent.txt")
  dedup <- file.path(prodir, "dedup", "gc_percent.txt")
  raw_melt <- data_manager(raw, "GC_Content", "Clean")
  dedup_melt <- data_manager(dedup, "GC_Content", "Dedup")
  data_melt <- rbind(raw_melt, dedup_melt)
  
  outpng <- file.path(prodir, "gc_percent_r1.png")
  plot_line(data_melt, outpng, "GC_Content", xlab_t = "GC Content (%)",
            title_t = "GC distribution over reads1",
            col = "variable", xtick = 5, key = "Reads1")
  
  if (length(levels(data_melt$variable)) == 2) {
    outpng <- file.path(prodir, "gc_percent_r2.png")
    plot_line(data_melt, outpng, "GC_Content", xlab_t = "GC Content (%)",
              title_t = "GC distribution over reads2",
              col = "variable", xtick = 5, key = "Reads2")
  }
  
  #Dup
  raw <- file.path(prodir, "uid", "duplication_levels.txt")
  dedup <- file.path(prodir, "dedup", "duplication_levels.txt")
  raw_melt <- dup_data_manager(raw, "Dup", "Clean")
  dedup_melt <- dup_data_manager(dedup, "Dup", "Dedup")
  data_melt <- rbind(raw_melt[[1]], dedup_melt[[1]])
  
  outpng <- file.path(prodir, "duplication_level_r1.png")
  plot_line_dup(data_melt, outpng, "Duplication distribution over reads1", raw_melt[[2]], col = "variable", key = "Reads1")
  
  if (length(levels(data_melt$variable)) == 2) {
    outpng <- file.path(prodir, "duplication_level_r2.png")
    plot_line_dup(data_melt, outpng, "Duplication distribution over reads2", raw_melt[[2]], col = "variable", key = "Reads2")
  }
}