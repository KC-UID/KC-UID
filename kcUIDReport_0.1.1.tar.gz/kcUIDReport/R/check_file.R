#' Read table and melt
#'
#' @param name of the input file
#' @param category of the file, gc_content, length or duplication
#' @param type of file, raw or dedup
#' @return data frame
#' @export

check_file <- function(file = "") {
  if (!file.exists(file)) {
    return(FALSE)
  } else {
    return(TRUE)
  }
}