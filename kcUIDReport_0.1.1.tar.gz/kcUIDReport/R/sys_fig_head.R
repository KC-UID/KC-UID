#' Read table and melt
#'
#' @param name of the input file
#' @param category of the file, gc_content, length or duplication
#' @param type of file, raw or dedup
#' @return data frame
#' @export

sys_fig_head <- function (file, title = NA, shape = "normal", width = NA)
{
  if (!file.exists(file)) {
    words <- "<p></p>"
    return(words)
  }
  src <- paste0("<br><p><center><img src='", file)
  if (!is.na(width)) {
    fig_code <- paste0(src, "' width='", width, "'/>")
  }
  fig_code
}