#' Read table and melt
#'
#' @param name of the input file
#' @param category of the file, gc_content, length or duplication
#' @param type of file, raw or dedup
#' @return data frame
#' @export

tb_kable_html <- function(data, digits = 3, align = "c", tbname = "", class = "normal_tb") {
  data <- data.frame(data, check.names = FALSE)
  code <- kable(data, format = "html", digits = digits, align = align, escape = FALSE) %>%
    kable_styling(bootstrap_options = c("striped", "hover", "condensed", "responsive"), full_width = T)
  code <- HTML("<center>", code, "</center>")
  #code <- HTML(code)
  code <- div(class = class, p(class = "name_tb", tbname), code)
  return(code)
}