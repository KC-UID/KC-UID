#' Read table and melt
#'
#' @param name of the input file
#' @param category of the file, gc_content, length or duplication
#' @param type of file, raw or dedup
#' @return data frame
#' @export

sys_fig <- function (file, title = NA, shape = "normal", width = NA)
{
  if (!file.exists(file)) {
    words <- "<p></p>"
    return(words)
  }
  src <- paste0("<br><p><center><img src='", file)
  if (!is.na(width)) {
    fig_code <- paste0(src, "' width='", width, "'/></a></center>")
  }
  else {
    fig_code <- paste0(src, "' class='", shape, "_fig'/></a></center></p>")
  }
  if (!is.na(title)) {
    fig_code <- paste(fig_code, "<br><p class='name_fig'>",
                      title, "</p><br>", sep = "")
  }
  fig_code
}