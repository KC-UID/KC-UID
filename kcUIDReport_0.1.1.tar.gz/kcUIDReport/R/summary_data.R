#' Read table and melt
#'
#' @param name of the input file
#' @param category of the file, gc_content, length or duplication
#' @param type of file, raw or dedup
#' @return data frame
#' @export

summary_data <- function(prodir, sample) {
  prodir <- file.path(prodir, sample)
  raw <- read.table(file.path(prodir, "raw", "summary.txt"), header = FALSE, sep = "\t")
  dedup <- read.table(file.path(prodir, "dedup", "summary.txt"), header = FALSE, sep = "\t")
  other <- read.table(file.path(prodir, "uid", "reads_count.txt"), header = FALSE, sep = "\t")
  input_reads <- raw[1,2]
  input_bases <- raw[2,2]
  input_gc <- raw[3,2]
  dedup_reads <- dedup[1,2]
  dedup_bases <- dedup[2,2]
  dedup_gc <- dedup[3,2]
  uid_reads <- other[1,2]
  con_reads <- other[2,2]
  uid_reads <- paste(uid_reads, " (", round(uid_reads/input_reads*100, 2), "%)", sep="")
  con_reads <- paste(con_reads, " (", round(con_reads/input_reads*100, 2), "%)", sep="")
  dedup_reads <- paste(dedup_reads, " (", round(dedup_reads/input_reads*100, 2), "%)", sep="")
  dedup_bases <- paste(dedup_bases, " (", round(dedup_bases/input_bases*100, 2),"%)", sep="")
  df <- data.frame(V1=c("Sample", "Inputs Reads", "Reads with UIDs", "Consensus Reads", 
                        "Dedup Reads", "Input Bases", "Input GC(%)", "Dedup Bases", "Dedup GC(%)"), 
                   V2=c(sample, input_reads, uid_reads, con_reads, dedup_reads, 
                        input_bases, input_gc, dedup_bases, dedup_gc))
  out <- file.path(prodir, "summary.txt")
  write.table(df, out, quote = FALSE, sep = "\t", col.names = FALSE, row.names = FALSE)
  
}