#' Extract the section number as "section_num" variable to keep the table and figure number continuous
#'
#' @param name of the input file
#' @param category of the file, gc_content, length or duplication
#' @param type of file, raw or dedup
#' @return data frame
#' @return labels
#' @export


plot_line <- function(data, outpng, xi, xlab_t, title_t, 
                      col = "variable", xtick = 1, key = "Reads1") {
  data_plot <- data[data[col] == key,]
  p <- ggplot(data_plot, aes(x = data_plot[,xi], y = value, color = Type)) +
    geom_line(size = 1) +
    theme_bw() +
    #theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank()) +
    #theme(panel.grid.major = element_blank()) +
    theme(plot.title = element_text(hjust = 0.5)) +
    theme(legend.title = element_blank()) +
    scale_x_continuous(breaks =seq(min(data_plot[,xi]), max(data_plot[,xi]), xtick)) +
    scale_color_manual(breaks=c("Clean", "Dedup"), values=c("red", "blue")) +
    ylab(NULL) +
    xlab(xlab_t) +
    theme(plot.title = element_text(hjust = 0.5)) +
    ggtitle(title_t)
  ggsave(filename = outpng,
         width = 9, height = 6, units = "in", dpi = 100,
         type="cairo-png", plot = p)
}
